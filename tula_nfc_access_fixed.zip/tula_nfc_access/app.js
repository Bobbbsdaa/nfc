const $ = (id) => document.getElementById(id);
const deviceState = $("deviceState");
const scanBtn = $("scanBtn");
const resultBox = $("resultBox");
const scanCaption = $("scanCaption");
const scanVisual = $("scanVisual");

const secureContext = window.isSecureContext;
const supportsNfc = "NDEFReader" in window;

if (!secureContext) {
  deviceState.textContent = "Нужен HTTPS";
} else if (supportsNfc) {
  deviceState.textContent = "Web NFC доступен";
} else {
  deviceState.textContent = "Ограничения браузера";
}

function showResult(title, body) {
  resultBox.hidden = false;
  resultBox.innerHTML = `<div class="result-title">${title}</div>${body}`;
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, ch => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[ch]));
}

let activeReader = null;
let scanActive = false;

function setScanning(active) {
  scanActive = active;
  scanBtn.disabled = active;
  scanBtn.querySelector("span").textContent = active ? "Сканирование активно…" : "Начать сканирование";
  scanCaption.textContent = active ? "ПОДНЕСИТЕ NFC-МЕТКУ К ТЕЛЕФОНУ" : "ГОТОВ К СКАНИРОВАНИЮ";
  scanVisual.classList.toggle("scanning", active);
}

function stopScanning() {
  setScanning(false);
  activeReader = null;
}

scanBtn.addEventListener("click", async () => {
  resultBox.hidden = true;

  if (scanActive) return;
  if (!secureContext) {
    showResult("Нужно защищённое соединение", "Откройте сайт по HTTPS. Web NFC обычно не работает при открытии HTML-файла напрямую из загрузок.");
    return;
  }
  if (!supportsNfc) {
    showResult("Браузер не предоставляет Web NFC", "Откройте сайт в актуальном Chrome на Android. Если Web NFC недоступен и там, браузер или устройство не поддерживает этот API.");
    return;
  }

  try {
    activeReader = new NDEFReader();
    const reader = activeReader;
    reader.onreadingerror = () => {
      showResult("Метка обнаружена, но NDEF не прочитан", "Попробуйте другую NFC-метку. Web NFC читает только совместимые NDEF-метки; многие карты и брелоки домофонов используют защищённые или не-NDEF форматы, которые сайт прочитать не может.");
      stopScanning();
    };

    reader.onreading = (event) => {
      const serial = event.serialNumber || "не предоставлен браузером";
      const records = [];

      for (const record of event.message.records) {
        let detail = `Тип записи: ${escapeHtml(record.recordType)}`;
        try {
          if (record.recordType === "text") {
            const decoder = new TextDecoder(record.encoding || "utf-8");
            detail += `<br>Текст: ${escapeHtml(decoder.decode(record.data))}`;
          } else if (record.recordType === "url") {
            detail += `<br>URL: ${escapeHtml(new TextDecoder().decode(record.data))}`;
          } else {
            detail += `<br>Размер данных: ${record.data ? record.data.byteLength : 0} байт`;
          }
        } catch (_) {
          detail += "<br>Содержимое этой записи не удалось отобразить.";
        }
        records.push(`<li>${detail}</li>`);
      }

      showResult("Метка прочитана", `
        <div><strong>Серийный номер:</strong> ${escapeHtml(serial)}</div>
        <div style="margin-top:8px"><strong>Записи NDEF:</strong></div>
        ${records.length ? `<ul>${records.join("")}</ul>` : "<p>Записей NDEF нет.</p>"}
        <p style="color:#aebbc2;margin-bottom:0">Это чтение доступных NDEF-данных. Защищённые ключи домофона не извлекаются, а доступ в здание не проверяется.</p>
      `);
      scanCaption.textContent = "МЕТКА ПРОЧИТАНА";
      stopScanning();
    };

    setScanning(true);
    await reader.scan();
    showResult("Сканирование активно", "Поднесите метку к задней панели телефона на 2–5 секунд. Если метка не обнаруживается, она может не поддерживать NDEF. Многие домофонные брелоки сайт прочитать не может.");
  } catch (err) {
    stopScanning();
    const message = err && err.name === "NotAllowedError"
      ? "Доступ к NFC не разрешён. Проверьте разрешения сайта/браузера и попробуйте снова."
      : err && err.name === "NotSupportedError"
        ? "Браузер или эта операция не поддерживаются. Попробуйте актуальный Chrome на Android через HTTPS."
        : `Не удалось запустить чтение: ${escapeHtml(err?.message || "неизвестная ошибка")}`;
    showResult("Сканирование не запущено", message);
  }
});

$("checkBtn").addEventListener("click", () => {
  const system = $("systemSelect").value;
  const access = $("accessSelect").value;
  let message = "";

  if (!system && !access) {
    message = "Выберите хотя бы один вариант, который знаете о домофоне.";
  } else if (access === "app") {
    message = "Уточните у управляющей компании или на панели домофона название официального приложения. Если система выдаёт мобильный ключ, следуйте её процедуре регистрации.";
  } else if (access === "card") {
    message = "Сам факт работы карты по NFC не означает, что её можно перенести в телефон. Уточните у обслуживающей организации, поддерживает ли система мобильный ключ или эмуляцию HCE.";
  } else if (access === "code") {
    message = "Попросите управляющую компанию подключить ваш номер телефона к официальному сервису доступа, если такой сервис предусмотрен.";
  } else {
    message = "По одному названию производителя нельзя надёжно определить тип ключа. Посмотрите модель панели или уточните у обслуживающей организации способ официального мобильного доступа.";
  }

  const selected = system ? `Выбрано: ${escapeHtml(system)}. ` : "";
  $("compatResult").hidden = false;
  $("compatResult").innerHTML = `<div class="result-title">Рекомендация</div>${selected}${escapeHtml(message)}<p style="color:#aebbc2;margin-bottom:0">Сайт не подключён к базам домофонов и не подтверждает доступ в конкретное здание.</p>`;
});

if ("serviceWorker" in navigator && location.protocol.startsWith("https")) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("./sw.js").catch(() => {});
  });
}
